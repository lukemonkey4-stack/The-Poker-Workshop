const DB = {
  key:"poker-workshop-v1",
  async getAll(){return JSON.parse(localStorage.getItem(this.key+":variants")||"null")||[]},
  async saveAll(items){localStorage.setItem(this.key+":variants",JSON.stringify(items))},
  async getGames(){return JSON.parse(localStorage.getItem(this.key+":games")||"[]")},
  async saveGames(items){localStorage.setItem(this.key+":games",JSON.stringify(items))}
};