const Mixer = {
 selected:[],
 add(v){if(!this.selected.some(x=>x.id===v.id))this.selected.push(v)},
 remove(id){this.selected=this.selected.filter(x=>x.id!==id)},
 clear(){this.selected=[]},
 validate(fields){
  const out=[];if(!this.selected.length)out.push({kind:"error",text:"Choose at least one source variant."});
  if(!fields.name.trim())out.push({kind:"error",text:"Give this custom game a name."});
  if(!fields.hole.trim())out.push({kind:"warn",text:"Starting deal is not defined."});
  if(!fields.board.trim())out.push({kind:"warn",text:"Board structure is not defined."});
  if(!fields.construction.trim())out.push({kind:"warn",text:"Hand construction is not defined."});
  if(!fields.betting.trim())out.push({kind:"warn",text:"Betting rounds are not defined."});
  if(!fields.special.trim()&&!this.selected.some(v=>v.mechanics?.length))out.push({kind:"warn",text:"No special mechanics have been defined."});
  if(!fields.winning.trim())out.push({kind:"warn",text:"Winning and tie-break rules need to be defined."});
  const names=this.selected.map(v=>v.name.toLowerCase());
  if(names.includes("omaha")&&names.includes("watermelon"))out.push({kind:"warn",text:"Omaha requires exactly 2 hole + 3 board cards; Watermelon describes Hold'em construction. Choose one construction rule."});
  if(names.includes("dragon fruit")&&names.includes("graveyard"))out.push({kind:"warn",text:"Both mechanics add or remove board cards. Define the exact order and final board size."});
  if(names.includes("blackjack poker")&&names.includes("strawberry"))out.push({kind:"warn",text:"Both variants use special river procedures. Define which river procedure takes priority."});
  if(out.length===0)out.push({kind:"ok",text:"No missing fields or known rule conflicts found by the basic checks."});
  return out;
 },
 makeBook(fields){return {id:"game-"+crypto.randomUUID(),name:fields.name,createdAt:new Date().toISOString(),sources:this.selected.map(v=>v.id),sourceNames:this.selected.map(v=>v.name),fields,rules:this.selected.map(v=>({name:v.name,rules:v.rules,mechanics:v.mechanics}))}}
};