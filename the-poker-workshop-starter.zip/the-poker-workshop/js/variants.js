const VariantStore = {
 items:[],
 async init(){const saved=await DB.getAll();if(!saved.length){const r=await fetch("./data/original-variants.json");this.items=await r.json();await DB.saveAll(this.items)}else this.items=saved;},
 async add(v){this.items.unshift(v);await DB.saveAll(this.items)},
 async replace(v){this.items=this.items.map(x=>x.id===v.id?v:x);await DB.saveAll(this.items)},
 async import(v){if(!v || !v.name || !v.startingDeal) throw new Error("This file does not look like a variant.");const clean={...v,id:v.id||"custom-"+crypto.randomUUID(),category:v.category||"Community"};this.items.unshift(clean);await DB.saveAll(this.items);return clean}
};