# The Poker Workshop

A public, offline-first poker variant creator built for static hosting (GitHub Pages). No AI, backend, accounts, analytics, or runtime API calls are required.

## Run locally
For service-worker/offline testing, serve this folder from localhost (service workers require a secure context):
- `python -m http.server 8000`
- Open `http://localhost:8000`

Opening `index.html` directly also loads the app in many browsers, but service-worker installation requires localhost or HTTPS.

## Publish with GitHub Pages
1. Create a public GitHub repository named `the-poker-workshop`.
2. Upload the contents of this folder to the repository root.
3. In Settings → Pages, choose Deploy from a branch, select `main` and `/ (root)`.
4. Visit the published Pages URL once while online. The service worker caches the app for later offline use.

## Community library model
GitHub Pages is static hosting: it cannot receive public submissions or write to a shared catalog. The `data/community-variants.json` file is the published community catalog. To contribute:
1. Export a variant JSON from the app.
2. Open a GitHub issue or pull request adding the validated variant to `data/community-variants.json`.
3. A maintainer reviews and merges it. The next site update publishes it to everyone.
This avoids introducing a runtime server. Personal variants remain in the user's browser until exported.

## Data and privacy
- Local variants and saved games are stored in browser localStorage.
- Export a backup regularly; browser data can be cleared by the user or browser.
- This starter does not send game data anywhere.
- Community catalog refresh requires internet; the rest of the cached application works offline.

## Important starter limitations
- The validator is a deterministic checklist and a small set of known conflict warnings, not a complete poker-rules theorem prover.
- Generated rulebooks include source descriptions and the choices entered by the user. Review unresolved questions before play.
- The supplied 12 starter variants are based on Custom Poker Variants Rulebook, Edition 1.
